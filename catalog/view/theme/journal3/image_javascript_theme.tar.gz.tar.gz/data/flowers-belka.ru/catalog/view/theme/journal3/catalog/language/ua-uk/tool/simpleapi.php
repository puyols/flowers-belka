<?php

$_['abandoned_mail_time'] = 'Час створення';
$_['abandoned_mail_email'] = 'Email';
$_['abandoned_mail_name'] = 'Ім\'я';
$_['abandoned_mail_telephone'] = 'Телефон';
$_['abandoned_mail_products'] = 'Товари';
$_['abandoned_mail_subject'] = 'Нові покинуті кошики';
