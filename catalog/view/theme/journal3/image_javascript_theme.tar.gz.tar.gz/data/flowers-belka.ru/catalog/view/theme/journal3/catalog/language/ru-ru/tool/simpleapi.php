<?php

$_['abandoned_mail_time'] = 'Время создания';
$_['abandoned_mail_email'] = 'Почта';
$_['abandoned_mail_name'] = 'Имя';
$_['abandoned_mail_telephone'] = 'Телефон';
$_['abandoned_mail_products'] = 'Товары';
$_['abandoned_mail_subject'] = 'Новые брошенные корзины';
